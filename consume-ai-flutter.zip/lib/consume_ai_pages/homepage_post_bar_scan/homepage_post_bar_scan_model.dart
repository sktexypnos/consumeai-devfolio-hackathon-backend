import '/flutter_flow/flutter_flow_util.dart';
import 'homepage_post_bar_scan_widget.dart' show HomepagePostBarScanWidget;
import 'package:flutter/material.dart';

class HomepagePostBarScanModel
    extends FlutterFlowModel<HomepagePostBarScanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
