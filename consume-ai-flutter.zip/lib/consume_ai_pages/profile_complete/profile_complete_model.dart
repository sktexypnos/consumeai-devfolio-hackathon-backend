import '/flutter_flow/flutter_flow_util.dart';
import 'profile_complete_widget.dart' show ProfileCompleteWidget;
import 'package:flutter/material.dart';

class ProfileCompleteModel extends FlutterFlowModel<ProfileCompleteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
