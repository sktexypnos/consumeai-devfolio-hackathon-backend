import '/flutter_flow/flutter_flow_util.dart';
import 'homepage_post_scan_widget.dart' show HomepagePostScanWidget;
import 'package:flutter/material.dart';

class HomepagePostScanModel extends FlutterFlowModel<HomepagePostScanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
