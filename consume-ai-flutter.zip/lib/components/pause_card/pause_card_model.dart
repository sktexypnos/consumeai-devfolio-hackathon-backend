import '/flutter_flow/flutter_flow_util.dart';
import 'pause_card_widget.dart' show PauseCardWidget;
import 'package:flutter/material.dart';

class PauseCardModel extends FlutterFlowModel<PauseCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
