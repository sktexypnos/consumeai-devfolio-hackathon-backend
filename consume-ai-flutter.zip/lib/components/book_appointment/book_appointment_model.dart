import '/flutter_flow/flutter_flow_util.dart';
import 'book_appointment_widget.dart' show BookAppointmentWidget;
import 'package:flutter/material.dart';

class BookAppointmentModel extends FlutterFlowModel<BookAppointmentWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
